
const { MongoClient } = require("mongodb");

const url = "mongodb://127.0.0.1:27017";
const client = new MongoClient(url);

async function run() {
    try {
        await client.connect();
        console.log("Connected to MongoDB!");

        const db = client.db("studentdb");
        const students = db.collection("students");

        // CREATE
        await students.insertOne({
            name: "Alice",
            age: 20
        });
        console.log("Record Inserted!");

        // READ
        const data = await students.find().toArray();
        console.log("Data Retrieved:", data);

        // UPDATE
        await students.updateOne(
            { name: "Alice" },
            { $set: { age: 21 } }
        );
        console.log("Record Updated!");

        // DELETE
        await students.deleteOne({ name: "Alice" });
        console.log("Record Deleted!");

    } catch (error) {
        console.error("Error:", error.message);
    } finally {
        await client.close();
    }
}

run();
