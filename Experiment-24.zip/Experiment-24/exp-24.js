
console.log("Welcome to Node.js!");
console.log("This is your first Node.js application.");
console.log("Node.js Version Check:");
console.log("Node.js is running successfully");
