
// Wait for DOM to load
document.addEventListener('DOMContentLoaded', function() {

    // Get form elements
    const form = document.getElementById('registrationForm');

    const username = document.getElementById('username');
    const email = document.getElementById('email');
    const phone = document.getElementById('phone');
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirmPassword');

    // Regular Expression Patterns
    const patterns = {
        username: /^[a-zA-Z0-9_]{3,16}$/,
        email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        phone: /^(\+\d{1,3}[- ]?)?\d{10}$/,
        password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
    };

    // Password Requirements
    const passwordChecks = {
        length: /.{8,}/,
        uppercase: /[A-Z]/,
        lowercase: /[a-z]/,
        number: /\d/,
        special: /[@$!%*?&]/
    };

    // Show Error
    function showError(input, errorElement, message) {
        input.classList.remove('success');
        input.classList.add('error');
        errorElement.textContent = message;
    }

    // Show Success
    function showSuccess(input, errorElement) {
        input.classList.remove('error');
        input.classList.add('success');
        errorElement.textContent = '';
    }

    // Validate Username
    function validateUsername() {
        const value = username.value.trim();
        const error = document.getElementById('usernameError');

        if (value === '') {
            showError(username, error, 'Username is required');
            return false;
        }

        if (value.length < 3) {
            showError(username, error, 'Username must be at least 3 characters');
            return false;
        }

        if (value.length > 16) {
            showError(username, error, 'Username must be less than 16 characters');
            return false;
        }

        if (!patterns.username.test(value)) {
            showError(username, error,
                'Only letters, numbers and underscores are allowed');
            return false;
        }

        showSuccess(username, error);
        return true;
    }

    // Validate Email
    function validateEmail() {
        const value = email.value.trim();
        const error = document.getElementById('emailError');

        if (value === '') {
            showError(email, error, 'Email is required');
            return false;
        }

        if (!patterns.email.test(value)) {
            showError(email, error, 'Please enter a valid email address');
            return false;
        }

        showSuccess(email, error);
        return true;
    }

    // Validate Phone Number
    function validatePhone() {
        const value = phone.value.trim();
        const error = document.getElementById('phoneError');

        if (value === '') {
            showError(phone, error, 'Phone number is required');
            return false;
        }

        if (!patterns.phone.test(value)) {
            showError(phone, error,
                'Please enter a valid 10-digit phone number');
            return false;
        }

        showSuccess(phone, error);
        return true;
    }

    // Validate Password
    function validatePassword() {
        const value = password.value;
        const error = document.getElementById('passwordError');

        // Update password requirements
        for (let check in passwordChecks) {
            const element = document.getElementById(check);

            if (passwordChecks[check].test(value)) {
                element.classList.add('valid');
            } else {
                element.classList.remove('valid');
            }
        }

        if (value === '') {
            showError(password, error, 'Password is required');
            return false;
        }

        if (!patterns.password.test(value)) {
            showError(password, error,
                'Password does not meet requirements');
            return false;
        }

        showSuccess(password, error);

        if (confirmPassword.value !== '') {
            validateConfirmPassword();
        }

        return true;
    }

    // Validate Confirm Password
    function validateConfirmPassword() {
        const value = confirmPassword.value;
        const error = document.getElementById('confirmPasswordError');

        if (value === '') {
            showError(confirmPassword, error,
                'Please confirm your password');
            return false;
        }

        if (value !== password.value) {
            showError(confirmPassword, error,
                'Passwords do not match');
            return false;
        }

        showSuccess(confirmPassword, error);
        return true;
    }

    // Real-time Username Validation
    username.addEventListener('blur', validateUsername);

    username.addEventListener('input', function() {
        if (username.classList.contains('error')) {
            validateUsername();
        }
    });

    // Real-time Email Validation
    email.addEventListener('blur', validateEmail);

    email.addEventListener('input', function() {
        if (email.classList.contains('error')) {
            validateEmail();
        }
    });

    // Real-time Phone Validation
    phone.addEventListener('blur', validatePhone);

    phone.addEventListener('input', function() {
        if (phone.classList.contains('error')) {
            validatePhone();
        }
    });

    // Password Validation
    password.addEventListener('input', validatePassword);

    // Confirm Password Validation
    confirmPassword.addEventListener('input',
        validateConfirmPassword);

    // Form Submission
    form.addEventListener('submit', function(e) {

        e.preventDefault();

        const isUsernameValid = validateUsername();
        const isEmailValid = validateEmail();
        const isPhoneValid = validatePhone();
        const isPasswordValid = validatePassword();
        const isConfirmPasswordValid = validateConfirmPassword();

        // Check all validations
        if (
            isUsernameValid &&
            isEmailValid &&
            isPhoneValid &&
            isPasswordValid &&
            isConfirmPasswordValid
        ) {

            const successMessage =
                document.getElementById('successMessage');

            successMessage.textContent =
                'Registration successful! Form submitted.';

            successMessage.classList.add('show');

            // Reset form after 2 seconds
            setTimeout(function() {

                form.reset();

                successMessage.classList.remove('show');

                // Remove input classes
                document.querySelectorAll('input').forEach(function(input) {
                    input.classList.remove('success', 'error');
                });

                // Reset password requirements
                Object.keys(passwordChecks).forEach(function(check) {
                    document.getElementById(check)
                        .classList.remove('valid');
                });

            }, 2000);

        } else {

            // Focus on first invalid field
            const firstError = form.querySelector('input.error');

            if (firstError) {
                firstError.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });

                firstError.focus();
            }
        }

    });

});
